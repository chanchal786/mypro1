package com.sprhiber.util;

public class ValidInput {
	private String input;

	public String getInput() {
		return input;
	}

	public void setInput(String input) {
		this.input = input;
	}
}
