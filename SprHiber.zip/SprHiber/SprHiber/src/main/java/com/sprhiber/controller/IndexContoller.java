package com.sprhiber.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.sprhiber.util.ValidForm;
import com.sprhiber.util.ValidInput;

@Controller
public class IndexContoller {
	static {
		System.out.println("Hi Conroller");
	}

	@RequestMapping("/")
	public String home() {
		System.out.println("Home Request");
		return "home";
	}

	@RequestMapping("validForm")
	public String validForm() {
		System.out.println("Valid form request");
		ValidInput validInput = new ValidInput();
		validInput.setInput(null);
		return "validForm";
	}

	@RequestMapping(value = "/validatingForm")
	public @ResponseBody Map<String, Object> validatingForm1(@RequestParam(value = "input") String input)
			throws IllegalStateException {
		Map<String, Object> map = new HashMap<String, Object>();
		System.out.println("Validing form request..........");
		System.out.println("Use input : " + input);
		ValidForm vform = new ValidForm();
		String out = vform.checkValid(input);
		List<String> list = new ArrayList<String>();
		list.add(out);
		System.out.println(list);
		if (list != null) {
			System.out.println("Is Not Null " + list);
			map.put("data", list);
		}
		System.out.println(map.size());
		for (Map.Entry<String, Object> entry : map.entrySet()) {
			System.out.println(entry.getKey() + " : " + entry.getValue());
		}
		return map;
	}
}
